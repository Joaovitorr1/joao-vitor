function X() {
var segunda = document.getElementById ("format");
format.innerHTML = 'PEITO: Supino Inclinado, Supino Reto, Pack Deck, Crucifixo Com Halters__BICEPS: Rosca Direta, Rosca Alternada com Halters, Rosca Scott, Puxada Supinada no Puley'
}
function X1() {
var terça = document.getElementById ("format1");
format1.innerHTML = 'OMBRO: elevação Latereal Com Halter, Levantamento Frontal com Halter, Remada Alta Com BarraStiff,__PERNA: Agachamento, LegPress, Passada UniLateral, Agachamento Sumô'
}
function X2() {
var quarta = document.getElementById ("format2");
format2.innerHTML = 'COSTA: puxada aberta no pulley, flexão de ombros cross, voador dorsal__TRICEPS: mergulho no banco,  Triceps apoiado no Banco, Triceps na Maquina, Francês'
}
function X3() {
var quinta = document.getElementById ("format3");
format3.innerHTML = 'PEITO: Supino Inclinado, Supino Reto, Pack Deck, Crucifixo Com Halters__Rosca Alternada com BICEPS: Rosca Diret Halters, Rosca Scott, Puxada Supinada no Puley'
}
function X4() {
var sexta = document.getElementById ("format4");
format4.innerHTML = 'CARDIO: Correr Na Esteira, Pular Corda, Simulador De caminhada__Exercicio Opcional'
}
function X5() {
var coach = document.getElementById ("Format5");
format5.innerHTML = 'acréscimo de 30 reais com supervisão de um Coach__Acompanhamento de uma Nutricionista Pago, e com Dieta balanceada'
}
function X6() {
alert('! QUE TODA INVEJA VIRE MASSA MUSCULAR. NO PAIN, NO GAIN! Obrigado, Volte sempre.')
}